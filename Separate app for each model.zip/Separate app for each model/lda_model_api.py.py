# -*- coding: utf-8 -*-

import pandas as pd
from pycaret.classification import load_model, predict_model
from fastapi import FastAPI
import uvicorn
from pydantic import create_model

# Create the app
app = FastAPI()

# Load trained Pipeline
model = load_model("lda_model_api.py")

# Create input/output pydantic models
input_model = create_model("lda_model_api.py_input", **{'left_wrist_x': 0.32285115122795105, 'left_wrist_y': 0.32859283685684204, 'left_wrist_z': -0.7431919574737549, 'left_shoulder_x': 0.6626759767532349, 'left_shoulder_y': 0.3189055919647217, 'left_shoulder_z': -0.6231910586357117, 'Left_Elbow_x': 0.48771965503692627, 'Left_Elbow_y': 0.33499079942703247, 'Left_Elbow_z': -0.7614650726318359, 'right_wrist_x': 0.31274598836898804, 'right_wrist_y': 0.3864498734474182, 'right_wrist_z': -0.03389732167124748, 'right_shoulder_x': 0.6146121025085449, 'right_shoulder_y': 0.32144805788993835, 'right_shoulder_z': 0.04444532468914986, 'right_Elbow_x': 0.4544891119003296, 'right_Elbow_y': 0.35198524594306946, 'right_Elbow_z': 0.10942106693983078, 'left_pinky_x': 0.279033362865448, 'left_pinky_y': 0.32499679923057556, 'left_pinky_z': -0.8236799240112305, 'right_pinky_x': 0.2818651497364044, 'right_pinky_y': 0.3885008692741394, 'right_pinky_z': -0.06181797757744789, 'left_index_x': 0.28480613231658936, 'left_index_y': 0.3184955418109894, 'left_index_z': -0.8005210757255554, 'right_index_x': 0.279132217168808, 'right_index_y': 0.39020323753356934, 'right_index_z': -0.1272868663072586, 'left_thumb_x': 0.302094429731369, 'left_thumb_y': 0.3227093815803528, 'left_thumb_z': -0.7343255877494812, 'right_thumb_x': 0.29064375162124634, 'right_thumb_y': 0.3907442092895508, 'right_thumb_z': -0.07259290665388107, 'left_hip_x': 0.6488996744155884, 'left_hip_y': 0.4944940209388733, 'left_hip_z': -0.19454841315746307, 'right_hip_x': 0.5984958410263062, 'right_hip_y': 0.4958493113517761, 'right_hip_z': 0.1940220594406128, 'left_knee_x': 0.6414526104927063, 'left_knee_y': 0.6184633374214172, 'left_knee_z': 0.04119018465280533, 'right_knee_x': 0.6145440340042114, 'right_knee_y': 0.6172922849655151, 'right_knee_z': 0.45855697989463806, 'left_ankle_x': 0.6541427969932556, 'left_ankle_y': 0.7433406710624695, 'left_ankle_z': 0.35003817081451416, 'right_ankle_x': 0.650362491607666, 'right_ankle_y': 0.7281537055969238, 'right_ankle_z': 0.804062008857727, 'left_heel_x': 0.6751874089241028, 'left_heel_y': 0.7706112861633301, 'left_heel_z': 0.3722474277019501, 'right_heel_x': 0.673480749130249, 'right_heel_y': 0.7501830458641052, 'right_heel_z': 0.8340920209884644, 'left_foot_index_x': 0.5531221628189087, 'left_foot_index_y': 0.7660739421844482, 'left_foot_index_z': 0.19788208603858948, 'right_foot_index_x': 0.5656631588935852, 'right_foot_index_y': 0.7458826303482056, 'right_foot_index_z': 0.7206758260726929})
output_model = create_model("lda_model_api.py_output", prediction=1.0)


# Define predict function
@app.post("/predict", response_model=output_model)
def predict(data: input_model):
    data = pd.DataFrame([data.dict()])
    predictions = predict_model(model, data=data)
    return {"prediction": predictions["prediction_label"].iloc[0]}


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)
