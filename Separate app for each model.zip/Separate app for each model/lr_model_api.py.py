# -*- coding: utf-8 -*-

import pandas as pd
from pycaret.classification import load_model, predict_model
from fastapi import FastAPI
import uvicorn
from pydantic import create_model

# Create the app
app = FastAPI()

# Load trained Pipeline
model = load_model("lr_model_api.py")

# Create input/output pydantic models
input_model = create_model("lr_model_api.py_input", **{'left_wrist_x': 0.2046346664428711, 'left_wrist_y': 0.45029765367507935, 'left_wrist_z': -0.5365076661109924, 'left_shoulder_x': 0.5545670986175537, 'left_shoulder_y': 0.36985114216804504, 'left_shoulder_z': -0.556290864944458, 'Left_Elbow_x': 0.382561594247818, 'Left_Elbow_y': 0.4252927899360657, 'Left_Elbow_z': -0.6226038932800293, 'right_wrist_x': 0.33391672372817993, 'right_wrist_y': 0.4429296851158142, 'right_wrist_z': 0.08358541131019592, 'right_shoulder_x': 0.6122190952301025, 'right_shoulder_y': 0.36281391978263855, 'right_shoulder_z': 0.11227613687515259, 'right_Elbow_x': 0.4921831786632538, 'right_Elbow_y': 0.4244772791862488, 'right_Elbow_z': 0.17969632148742676, 'left_pinky_x': 0.15347017347812653, 'left_pinky_y': 0.4471454620361328, 'left_pinky_z': -0.6169899106025696, 'right_pinky_x': 0.3103349804878235, 'right_pinky_y': 0.4397493302822113, 'right_pinky_z': 0.08137567341327667, 'left_index_x': 0.15637458860874176, 'left_index_y': 0.43956664204597473, 'left_index_z': -0.5747458934783936, 'right_index_x': 0.29949676990509033, 'right_index_y': 0.43811464309692383, 'right_index_z': 0.009698367677628994, 'left_thumb_x': 0.1762278825044632, 'left_thumb_y': 0.4427097737789154, 'left_thumb_z': -0.5182663202285767, 'right_thumb_x': 0.3037593364715576, 'right_thumb_y': 0.4427761137485504, 'right_thumb_z': 0.04981787130236626, 'left_hip_x': 0.5557524561882019, 'left_hip_y': 0.5625063180923462, 'left_hip_z': -0.20021896064281464, 'right_hip_x': 0.6139029264450073, 'right_hip_y': 0.5606462955474854, 'right_hip_z': 0.2000158727169037, 'left_knee_x': 0.521223783493042, 'left_knee_y': 0.696053147315979, 'left_knee_z': -0.03358679264783859, 'right_knee_x': 0.5928083062171936, 'right_knee_y': 0.689001202583313, 'right_knee_z': 0.43086355924606323, 'left_ankle_x': 0.5234999656677246, 'left_ankle_y': 0.8353334665298462, 'left_ankle_z': 0.1564958095550537, 'right_ankle_x': 0.6056591272354126, 'right_ankle_y': 0.8204114437103271, 'right_ankle_z': 0.6737140417098999, 'left_heel_x': 0.5479985475540161, 'left_heel_y': 0.863577127456665, 'left_heel_z': 0.16924463212490082, 'right_heel_x': 0.6261086463928223, 'right_heel_y': 0.8408122062683105, 'right_heel_z': 0.6981951594352722, 'left_foot_index_x': 0.4413723349571228, 'left_foot_index_y': 0.8437380790710449, 'left_foot_index_z': 0.06996870040893555, 'right_foot_index_x': 0.5229986310005188, 'right_foot_index_y': 0.8292343020439148, 'right_foot_index_z': 0.6386232972145081})
output_model = create_model("lr_model_api.py_output", prediction=1.0)


# Define predict function
@app.post("/predict", response_model=output_model)
def predict(data: input_model):
    data = pd.DataFrame([data.dict()])
    predictions = predict_model(model, data=data)
    return {"prediction": predictions["prediction_label"].iloc[0]}


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)
