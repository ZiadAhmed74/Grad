# -*- coding: utf-8 -*-

import pandas as pd
from pycaret.classification import load_model, predict_model
from fastapi import FastAPI
import uvicorn
from pydantic import create_model

# Create the app
app = FastAPI()

# Load trained Pipeline
model = load_model("rf_model_api.py")

# Create input/output pydantic models
input_model = create_model("rf_model_api.py_input", **{'left_wrist_x': 0.7787368893623352, 'left_wrist_y': 0.5413892865180969, 'left_wrist_z': -0.6876818537712097, 'left_shoulder_x': 0.7649906873703003, 'left_shoulder_y': 0.3549806475639343, 'left_shoulder_z': -0.5343213677406311, 'Left_Elbow_x': 0.7916961312294006, 'Left_Elbow_y': 0.4559359848499298, 'Left_Elbow_z': -0.5072615146636963, 'right_wrist_x': 0.24308957159519196, 'right_wrist_y': 0.3503011465072632, 'right_wrist_z': -0.3921731114387512, 'right_shoulder_x': 0.542628288269043, 'right_shoulder_y': 0.323429137468338, 'right_shoulder_z': -0.3844994902610779, 'right_Elbow_x': 0.3954605162143707, 'right_Elbow_y': 0.34741148352622986, 'right_Elbow_z': -0.2680414021015167, 'left_pinky_x': 0.7760772109031677, 'left_pinky_y': 0.5716450214385986, 'left_pinky_z': -0.7395489811897278, 'right_pinky_x': 0.19640898704528809, 'right_pinky_y': 0.34469446539878845, 'right_pinky_z': -0.42599302530288696, 'left_index_x': 0.7629340291023254, 'left_index_y': 0.5690668821334839, 'left_index_z': -0.8075661063194275, 'right_index_x': 0.1926749050617218, 'right_index_y': 0.34210485219955444, 'right_index_z': -0.5137859582901001, 'left_thumb_x': 0.7573078274726868, 'left_thumb_y': 0.5590015053749084, 'left_thumb_z': -0.7169651985168457, 'right_thumb_x': 0.2101186215877533, 'right_thumb_y': 0.3471355438232422, 'right_thumb_z': -0.43826407194137573, 'left_hip_x': 0.6704504489898682, 'left_hip_y': 0.5292471051216125, 'left_hip_z': -0.014813901856541634, 'right_hip_x': 0.5524213314056396, 'right_hip_y': 0.5226315855979919, 'right_hip_z': 0.014766820706427097, 'left_knee_x': 0.651538610458374, 'left_knee_y': 0.6530612111091614, 'left_knee_z': 0.138163760304451, 'right_knee_x': 0.5270578861236572, 'right_knee_y': 0.6449259519577026, 'right_knee_z': 0.0918227806687355, 'left_ankle_x': 0.65415358543396, 'left_ankle_y': 0.7641139626502991, 'left_ankle_z': 0.5490097999572754, 'right_ankle_x': 0.5114423036575317, 'right_ankle_y': 0.7623644471168518, 'right_ankle_z': 0.4535638093948364, 'left_heel_x': 0.6330254077911377, 'left_heel_y': 0.7805256247520447, 'left_heel_z': 0.5758605599403381, 'right_heel_x': 0.524643063545227, 'right_heel_y': 0.7768702507019043, 'right_heel_z': 0.4750048518180847, 'left_foot_index_x': 0.682403028011322, 'left_foot_index_y': 0.8154293298721313, 'left_foot_index_z': 0.3472059965133667, 'right_foot_index_x': 0.46827200055122375, 'right_foot_index_y': 0.8084772825241089, 'right_foot_index_z': 0.22841772437095642})
output_model = create_model("rf_model_api.py_output", prediction=4.0)


# Define predict function
@app.post("/predict", response_model=output_model)
def predict(data: input_model):
    data = pd.DataFrame([data.dict()])
    predictions = predict_model(model, data=data)
    return {"prediction": predictions["prediction_label"].iloc[0]}


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)
