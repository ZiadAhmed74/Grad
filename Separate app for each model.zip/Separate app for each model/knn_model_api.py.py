# -*- coding: utf-8 -*-

import pandas as pd
from pycaret.classification import load_model, predict_model
from fastapi import FastAPI
import uvicorn
from pydantic import create_model

# Create the app
app = FastAPI()

# Load trained Pipeline
model = load_model("knn_model_api.py")

# Create input/output pydantic models
input_model = create_model("knn_model_api.py_input", **{'left_wrist_x': 0.8169898390769958, 'left_wrist_y': 0.5189937353134155, 'left_wrist_z': -0.909900426864624, 'left_shoulder_x': 0.7818480730056763, 'left_shoulder_y': 0.3219703435897827, 'left_shoulder_z': -0.6588212251663208, 'Left_Elbow_x': 0.8068601489067078, 'Left_Elbow_y': 0.42744696140289307, 'Left_Elbow_z': -0.6680582165718079, 'right_wrist_x': 0.23903948068618774, 'right_wrist_y': 0.3443661332130432, 'right_wrist_z': -0.6077826023101807, 'right_shoulder_x': 0.5471305251121521, 'right_shoulder_y': 0.30269429087638855, 'right_shoulder_z': -0.50941401720047, 'right_Elbow_x': 0.3986821472644806, 'right_Elbow_y': 0.33502086997032166, 'right_Elbow_z': -0.42458656430244446, 'left_pinky_x': 0.8160378336906433, 'left_pinky_y': 0.5443350076675415, 'left_pinky_z': -0.9806855916976929, 'right_pinky_x': 0.19230663776397705, 'right_pinky_y': 0.3419162631034851, 'right_pinky_z': -0.657088577747345, 'left_index_x': 0.8042083978652954, 'left_index_y': 0.5439044833183289, 'left_index_z': -1.0513132810592651, 'right_index_x': 0.1897294968366623, 'right_index_y': 0.3408823609352112, 'right_index_z': -0.7471561431884766, 'left_thumb_x': 0.7998195290565491, 'left_thumb_y': 0.5348923802375793, 'left_thumb_z': -0.9437199234962463, 'right_thumb_x': 0.20921076834201813, 'right_thumb_y': 0.3441956639289856, 'right_thumb_z': -0.6556114554405212, 'left_hip_x': 0.6991168856620789, 'left_hip_y': 0.5055550932884216, 'left_hip_z': -0.017166944220662117, 'right_hip_x': 0.5770907998085022, 'right_hip_y': 0.5008043646812439, 'right_hip_z': 0.017092887312173843, 'left_knee_x': 0.6977184414863586, 'left_knee_y': 0.6357061862945557, 'left_knee_z': 0.13449400663375854, 'right_knee_x': 0.5618019700050354, 'right_knee_y': 0.6315715312957764, 'right_knee_z': 0.17692431807518005, 'left_ankle_x': 0.6911455392837524, 'left_ankle_y': 0.7372161746025085, 'left_ankle_z': 0.7224055528640747, 'right_ankle_x': 0.5533840656280518, 'right_ankle_y': 0.7405892014503479, 'right_ankle_z': 0.7118986248970032, 'left_heel_x': 0.6703493595123291, 'left_heel_y': 0.7484069466590881, 'left_heel_z': 0.7688454389572144, 'right_heel_x': 0.5683972239494324, 'right_heel_y': 0.7530756592750549, 'right_heel_z': 0.7534213662147522, 'left_foot_index_x': 0.7260949611663818, 'left_foot_index_y': 0.7934643626213074, 'left_foot_index_z': 0.5318407416343689, 'right_foot_index_x': 0.51007479429245, 'right_foot_index_y': 0.7934296727180481, 'right_foot_index_z': 0.4962178170681})
output_model = create_model("knn_model_api.py_output", prediction=3.0)


# Define predict function
@app.post("/predict", response_model=output_model)
def predict(data: input_model):
    data = pd.DataFrame([data.dict()])
    predictions = predict_model(model, data=data)
    return {"prediction": predictions["prediction_label"].iloc[0]}


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)
