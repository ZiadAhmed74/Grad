# -*- coding: utf-8 -*-

import pandas as pd
from pycaret.classification import load_model, predict_model
from fastapi import FastAPI
import uvicorn
from pydantic import create_model

# Create the app
app = FastAPI()

# Load trained Pipeline
model = load_model("nb_model_api.py")

# Create input/output pydantic models
input_model = create_model("nb_model_api.py_input", **{'left_wrist_x': 0.2687450051307678, 'left_wrist_y': 0.40740302205085754, 'left_wrist_z': -0.6309840679168701, 'left_shoulder_x': 0.6276006102561951, 'left_shoulder_y': 0.3307854235172272, 'left_shoulder_z': -0.5855067372322083, 'Left_Elbow_x': 0.4469687342643738, 'Left_Elbow_y': 0.388581782579422, 'Left_Elbow_z': -0.7139462232589722, 'right_wrist_x': 0.4979918897151947, 'right_wrist_y': 0.3846113979816437, 'right_wrist_z': 0.5320457816123962, 'right_shoulder_x': 0.6595702171325684, 'right_shoulder_y': 0.32630136609077454, 'right_shoulder_z': 0.1973779797554016, 'right_Elbow_x': 0.5836848020553589, 'right_Elbow_y': 0.376905620098114, 'right_Elbow_z': 0.42828068137168884, 'left_pinky_x': 0.21181122958660126, 'left_pinky_y': 0.409788578748703, 'left_pinky_z': -0.6997641324996948, 'right_pinky_x': 0.4917273223400116, 'right_pinky_y': 0.38166844844818115, 'right_pinky_z': 0.5587940812110901, 'left_index_x': 0.2084062397480011, 'left_index_y': 0.40053072571754456, 'left_index_z': -0.6765367388725281, 'right_index_x': 0.4836285412311554, 'right_index_y': 0.37609395384788513, 'right_index_z': 0.5079349279403687, 'left_thumb_x': 0.23122985661029816, 'left_thumb_y': 0.4030601382255554, 'left_thumb_z': -0.615459680557251, 'right_thumb_x': 0.4832935333251953, 'right_thumb_y': 0.3788856863975525, 'right_thumb_z': 0.5099577307701111, 'left_hip_x': 0.6017339825630188, 'left_hip_y': 0.5352399945259094, 'left_hip_z': -0.24619130790233612, 'right_hip_x': 0.6115485429763794, 'right_hip_y': 0.529085636138916, 'right_hip_z': 0.2459135800600052, 'left_knee_x': 0.5629460215568542, 'left_knee_y': 0.6866004467010498, 'left_knee_z': -0.06608334928750992, 'right_knee_x': 0.6274397373199463, 'right_knee_y': 0.6786248087882996, 'right_knee_z': 0.506731390953064, 'left_ankle_x': 0.5617053508758545, 'left_ankle_y': 0.8359988927841187, 'left_ankle_z': 0.11885343492031097, 'right_ankle_x': 0.6629759073257446, 'right_ankle_y': 0.8012814521789551, 'right_ankle_z': 0.8169485330581665, 'left_heel_x': 0.591576099395752, 'left_heel_y': 0.8632935881614685, 'left_heel_z': 0.13030414283275604, 'right_heel_x': 0.69282466173172, 'right_heel_y': 0.8305733799934387, 'right_heel_z': 0.8464476466178894, 'left_foot_index_x': 0.4437659680843353, 'left_foot_index_y': 0.8654277920722961, 'left_foot_index_z': -0.028600558638572693, 'right_foot_index_x': 0.5769338011741638, 'right_foot_index_y': 0.8188201189041138, 'right_foot_index_z': 0.768464207649231})
output_model = create_model("nb_model_api.py_output", prediction=1.0)


# Define predict function
@app.post("/predict", response_model=output_model)
def predict(data: input_model):
    data = pd.DataFrame([data.dict()])
    predictions = predict_model(model, data=data)
    return {"prediction": predictions["prediction_label"].iloc[0]}


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)
